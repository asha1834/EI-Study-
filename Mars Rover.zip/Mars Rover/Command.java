public interface Command {
    void execute(Rover rover);
}




