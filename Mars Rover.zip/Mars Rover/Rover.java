public class Rover {
    private Position position;
    private Direction direction;
    private Grid grid;

    public Rover(Position startPosition, Direction startDirection, Grid grid) {
        this.position = startPosition;
        this.direction = startDirection;
        this.grid = grid;
    }

    public void executeCommand(Command command) {
        command.execute(this);
    }

    public void move() {
        Position newPosition = direction.move(position);
        if (grid.isPositionValid(newPosition)) {
            position = newPosition;
        }
    }

    public void turnLeft() {
        direction = direction.turnLeft();
    }

    public void turnRight() {
        direction = direction.turnRight();
    }

    public String statusReport() {
        return "Rover is at " + position + " facing " + direction;
    }

    public Position getPosition() {
        return position;
    }

    public Direction getDirection() {
        return direction;
    }
}
