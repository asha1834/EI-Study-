import java.util.HashSet;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        // Create obstacles
        Set<Position> obstacles = new HashSet<>();
        obstacles.add(new Position(2, 2));
        obstacles.add(new Position(3, 5));

        // Create a grid
        Grid grid = new Grid(10, 10, obstacles);

        // Initialize the rover
        Rover rover = new Rover(new Position(0, 0), Direction.NORTH, grid);

        // Define commands
        Command move = new MoveCommand();
        Command turnLeft = new TurnLeftCommand();
        Command turnRight = new TurnRightCommand();

        // Execute commands
        rover.executeCommand(move); // Move to (0, 1)
        rover.executeCommand(move); // Move to (0, 2)
        rover.executeCommand(turnRight); // Turn to EAST
        rover.executeCommand(move); // Move to (1, 2)
        rover.executeCommand(turnLeft); // Turn to NORTH
        rover.executeCommand(move); // Move to (1, 3)

        // Print final status
        System.out.println(rover.statusReport());
    }
}
